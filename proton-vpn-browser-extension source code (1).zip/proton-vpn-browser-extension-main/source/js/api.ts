import {
	apiDomainsExclusion,
	baseAPIURL,
	getFullAppVersion,
	incompatibleSoftware,
	routes,
} from './config';
import {readSession} from './account/readSession';
import {getAuthHeaders} from './account/getAuthHeaders';
import type {Session} from './account/Session';
import {refreshToken} from './account/refreshToken';
import {getRegisteredLocale} from './account/user/getRegisteredLocale';
import {matchDomainList} from './tools/matchDomainList';
import {getLocale} from './tools/locale';
import {c} from './tools/translate';
import {milliSeconds} from './tools/milliSeconds';
import type {ExtensionUpdate} from './tools/broadcastMessage';
import {broadcastMessage} from './tools/broadcastMessage';
import {getUpdateError, setUpdateError} from './tools/update';
import {delay} from './tools/delay';
import {warn} from './log/log';
import {getBrowserSubType} from './tools/getBrowserSubType';
import {handleError} from './tools/sentry';
import {makeResponseReplayable} from './tools/makeResponseReplayable';
import OnRequestDetails = browser.proxy._OnRequestDetails;

export enum ErrorActionCode {
	UPGRADE = 'Upgrade',
	SIGN_OUT = 'SignOut',
	REFRESH = 'Refresh',
}

export enum ErrorActionCategory {
	MAIN_ACTION = 'main_action',
	SECONDARY_ACTION = 'secondary_action',
	LINK = 'link',
}

export interface ErrorAction {
	Code: ErrorActionCode;
	Category: ErrorActionCategory;
	Name: string;
	URL: string;
}

export interface DeviceLimitErrorDetails {
	Type: 'DeviceLimit';
	Title?: string;
	Body?:
		| string
		| Array<{
				Component: string;
				Icon: string;
				Text: string;
		  }>;
	Hint?: string;
	Actions?: ErrorAction[];
}

type DataResult = Record<string, unknown>;

export interface ApiError<
	T = DataResult | DeviceLimitErrorDetails,
	S extends number = number,
	C extends number = number,
> {
	httpStatus: S;
	Code: C;
	Error: string;
	Details?: T;
	Warning?: boolean;
	_id?: string;
}

export type UnauthorizedError<
	T = DataResult,
	C extends number = number,
> = ApiError<T, 401, C>;

export type ForbiddenError<
	T = DataResult,
	C extends number = number,
> = ApiError<T, 403, C>;

export type InvalidTokenError<T = DataResult> = UnauthorizedError<T, 401>;

export type ResponseResult = DataResult | ArrayBuffer;

const isObject = (value: unknown) =>
	typeof value === 'object' && value !== null;

export const isSuccessfulResponse = (response: Response): boolean =>
	response.status >= 200 && response.status < 300;

export const isNetworkError = (error: unknown): boolean =>
	isObject(error) &&
	((error as {name?: string}).name === 'NetworkError' ||
		/^(NetworkError |(TypeError: )?Failed to fetch)/.test(
			(error as {message?: string}).message || '',
		));

export const hasErrorHttpStatus = (
	error: unknown,
	httpStatus: number,
): error is ApiError =>
	isObject(error) && (error as {httpStatus?: number}).httpStatus === httpStatus;

export const isNotModified = (
	response: unknown,
): response is ApiError<unknown, 304, number> | {status: 304} =>
	(response as {status?: number})?.status === 304 ||
	hasErrorHttpStatus(response, 304);

export const isNotFoundError = (error: unknown): error is UnauthorizedError =>
	hasErrorHttpStatus(error, 404);

export const isUnauthorizedError = (
	error: unknown,
): error is UnauthorizedError => hasErrorHttpStatus(error, 401);

export const isInvalidTokenError = (
	error: unknown,
): error is InvalidTokenError =>
	isUnauthorizedError(error) && error.Code === 401;

export const isForbiddenError = (error: unknown): error is ForbiddenError =>
	hasErrorHttpStatus(error, 403);

export const isDeviceLimitError = (
	error: unknown,
): error is ApiError<DeviceLimitErrorDetails> =>
	((error as ApiError)?.Details as {Type?: string})?.Type === 'DeviceLimit';

export const needsLogout = (error: unknown): error is ApiError =>
	isObject(error) &&
	((error as {Code?: number}).Code === 2028 ||
		(error as {Code?: number}).Code === 2027);

export const needsUpdate = (error: unknown): error is ApiError =>
	isObject(error) && (error as {Code?: number}).Code === 5003;

export const isRetriableResponse = (response: Response): boolean =>
	response.status === 429;

export const isRetriableError = (error: unknown): error is ApiError =>
	isObject(error) &&
	((error as {Code?: number}).Code === 429 ||
		(error as {Code?: number}).Code === 503);

export const jsonRequest = (
	method: string,
	body: unknown,
	headers: Record<string, string> = {},
) => ({
	method,
	headers: {
		Accept: 'application/json',
		'Content-Type': 'application/json',
		...headers,
	},
	body: JSON.stringify(body),
});

/**
 * Object to remember for each route (method + URL) until when (time)
 * we should not re-fetch (and so return instead the memorized response)
 */
const retryAfterPerRoute: Record<string, {time: number; response: Response}> =
	{};

/**
 * Return millisecond-timestamp.
 */
const getRetryAfterTimestamp = (
	response: Response,
	defaultNumberOfSeconds = 0,
) => {
	const retryAfterHeader = `${response.headers.get('Retry-After') || defaultNumberOfSeconds}`;

	return Math.min(
		// Let's have a maximum of 7 days in case server went crazy
		Date.now() + milliSeconds.fromDays(7),
		// If the Retry-After is all digit
		/^\d+$/.test(retryAfterHeader)
			? // Then it's a number of seconds (as per https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Retry-After)
				Date.now() +
					milliSeconds.fromSeconds(Math.max(10, Number(retryAfterHeader)))
			: // Else, it's a date string
				new Date(retryAfterHeader).getTime(),
	);
};

const routeRegExps = Object.values(routes).reduce(
	(regExps, route) => {
		regExps[route] = new RegExp(`^${route.replace(/\{[^}]+}/g, '[^/]+')}$`);

		return regExps;
	},
	{} as Record<string, RegExp>,
);

const getRoute = (method: string, url: string) => {
	const path = url.split('?')[0] as string;

	for (const route of routes) {
		if (routeRegExps[route]!.test(path)) {
			return `${method} ${route}`;
		}
	}

	return `${method} ${path}`;
};

export const fetchApi = async (
	url: string,
	init?: RequestInit,
	baseUrl?: string,
	inputSession?: Session,
	tryUntil?: number,
): Promise<Response> => {
	const route = getRoute(init?.method || 'GET', url);
	const retryInfo = retryAfterPerRoute[route];

	if (retryInfo) {
		// Give the last received response if we are ordered not to retry before a certain time
		if (retryInfo.time >= Date.now()) {
			// We clone it so we can do .text() or .json() on it
			return retryInfo.response;
		}

		// If delay is over, we can forget
		delete retryAfterPerRoute[route];
	}

	const headers = (init?.headers || {}) as Record<string, string>;

	if (!headers['x-pm-uid']) {
		const session = inputSession || (await readSession());

		if (!session.expiresAt) {
			const uid = session?.uid;
			const accessToken = session?.accessToken;

			if (uid && accessToken) {
				Object.assign(headers, getAuthHeaders(uid, accessToken));
				headers['x-pm-locale'] ??= (await getRegisteredLocale()) || getLocale();
			}
		} else if (!inputSession && (tryUntil || 0) < Date.now()) {
			await delay(200);

			return fetchApi(
				url,
				init,
				baseUrl,
				inputSession,
				tryUntil || milliSeconds.fromSeconds(8, Date.now()),
			);
		}
	}

	const options = {
		mode: 'cors',
		credentials: 'include',
		redirect: 'follow',
		method: 'GET',
		...init,
		headers: {
			'x-pm-appversion': getFullAppVersion(),
			'x-pm-browser-type': await getBrowserSubType(),
			...headers,
		},
	} as RequestInit;

	const response = await fetch(`${baseUrl || baseAPIURL}${url}`, options);

	// If 429 / 503, check the Retry-After header
	// We don't handle the retry-logic here, it must be handled case by case if and
	// how many times we retry a given route in a given situation.
	// But we will ensure here that whatever is the specific logic it can never
	// retry sooner than what instructs the Retry-After sent by the server
	if (isRetriableResponse(response)) {
		const retryAfter = getRetryAfterTimestamp(response);

		if ((retryAfterPerRoute[route]?.time || 0) < retryAfter) {
			retryAfterPerRoute[route] = {
				time: retryAfter,
				response: makeResponseReplayable(response),
			};
		}
	}

	return response;
};

const startLikeHtml = (text: string) => /^\s*</.test(text);

const guessBlockerFromHtml = (html: string) => {
	for (const blocker of incompatibleSoftware) {
		if (html.includes(blocker)) {
			return blocker;
		}
	}

	return null;
};

const getBlockingSoftwareErrorFromResponse = (text: string) => {
	const blockingSoftware = guessBlockerFromHtml(text);

	if (blockingSoftware) {
		return new Error(
			c('Info')
				.t`VPN blocked by external software: ${blockingSoftware}.\n\nSome tools, like anti-viruses or proxies, can interfere with Proton VPN. You can try disabling it to confirm.`,
		);
	}

	handleError(
		'HTML Content Received: ' +
			text
				.replace(/<script[^>]*>[\s\S]*?<\/script[^>]*>/gi, '')
				.replace(/<style[^>]*>[\s\S]*?<\/style[^>]*>/gi, '')
				.replace(/src=["']data:[^"']+["']/gi, ''),
	);

	return new Error(
		c('Info')
			.t`VPN blocked by external software.\n\nSome tools, like anti-viruses or proxies, can interfere with Proton VPN. Disable them and retry.`,
	);
};

const checkIfResponseWasBlocked = async (response: Response) => {
	const text = await response.text();

	if (startLikeHtml(text)) {
		throw getBlockingSoftwareErrorFromResponse(text);
	}

	return text;
};

/**
 * Get response as JSON if possible, else return generic error.
 *
 * Note: most of the error should not trigger this because this function is called when
 * HTTP status is 200, so well-formed JSON is expected.
 */
const getJsonContent = async <T extends ResponseResult = ResponseResult>(
	response: Response,
): Promise<T> => {
	try {
		const clone = response.clone();
		const type = response.headers.get('Content-Type');

		return await (type === 'application/octet-stream'
			? clone.arrayBuffer()
			: clone.json());
	} catch (e) {
		await checkIfResponseWasBlocked(response);

		warn(response.status, e);

		throw new Error(c('Error').t`Service temporarily unavailable`);
	}
};

const buildResponseResult = async <T, D>(
	response: Response,
	resultBuilder?: (response: Response, data: D) => T,
): Promise<T> => {
	const data = await getJsonContent(response);

	return resultBuilder ? resultBuilder(response, data as D) : (data as T);
};

/**
 * Get response as JSON if possible, or else as text, to be used for unexpected output
 * such as API error responses that may or may not contain JSON.
 */
const getResponseContent = async <T extends DataResult = DataResult>(
	response: Response,
): Promise<T | string> => {
	try {
		return await response.clone().json();
	} catch {
		return await checkIfResponseWasBlocked(response);
	}
};

export const fetchJson = async <T, D extends ResponseResult = ResponseResult>(
	url: string,
	init?: RequestInit,
	baseUrl?: string,
	resultBuilder?: (response: Response, data: D) => T,
): Promise<T> => {
	const upgradeError = await getUpdateError();

	// If we have a recent force-upgrade, useless to call API
	if (upgradeError) {
		broadcastMessage<ExtensionUpdate>('updateExtension', {error: upgradeError});

		throw upgradeError;
	}

	const response = await fetchApi(url, init, baseUrl);

	if (!isSuccessfulResponse(response)) {
		const data = (await getResponseContent(response)) as unknown;
		const error = (data as ApiError)?.Error ? data : new Error(data as string);
		(error as {response?: Response}).response = response;

		if (isObject(error)) {
			(error as {httpStatus?: number}).httpStatus = response.status;
		}

		if (needsUpdate(data)) {
			broadcastMessage<ExtensionUpdate>('updateExtension', {
				error: error as ApiError,
			});
			setUpdateError(data);

			throw error;
		}

		setUpdateError(undefined);

		if (!/\/?auth(\/.*)$/.test(url) && isInvalidTokenError(error)) {
			const oldSession = await readSession();
			const oldUid = oldSession.uid;
			const oldAccessToken = oldSession.accessToken;
			const newSession = await refreshToken(oldSession);

			if (
				newSession.uid &&
				newSession.accessToken &&
				(newSession.uid !== oldUid || newSession.accessToken !== oldAccessToken)
			) {
				const retryResponse = await fetchApi(url, init, baseUrl, newSession);

				if (isSuccessfulResponse(retryResponse)) {
					return buildResponseResult<T, D>(retryResponse, resultBuilder);
				}
			}

			warn(error);
		}

		throw error;
	}

	setUpdateError(undefined);

	return buildResponseResult<T, D>(response, resultBuilder);
};

const isUrlExcluded = (url: URL, apiExclusion: boolean) =>
	apiDomainsExclusion.includes(url.hostname) &&
	(apiExclusion || /^\/?(api\/)?vpn\/location(\?.*)?$/.test(url.pathname));

export const isExcludedFromProxy = (
	requestInfo: OnRequestDetails,
	apiExclusion: boolean,
	bypassList?: string[] | undefined,
): boolean => {
	const url = new URL(requestInfo.url);

	if (isUrlExcluded(url, apiExclusion)) {
		return true;
	}

	return matchDomainList(bypassList || [], requestInfo, url.hostname);
};

export const isIncludedIntoProxy = (
	requestInfo: OnRequestDetails,
	apiExclusion: boolean,
	includeOnlyList?: string[] | undefined,
): boolean => {
	const url = new URL(requestInfo.url);

	if (isUrlExcluded(url, apiExclusion)) {
		return false;
	}

	if (typeof includeOnlyList === 'undefined') {
		return true;
	}

	return matchDomainList(includeOnlyList, requestInfo, url.hostname);
};
